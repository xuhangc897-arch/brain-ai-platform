(function () {
  const platform = window.BrainPlatform;
  const integration = window.BrainExperimentIntegration;

  const root = document.getElementById("reviewRoot");
  const printBtn = document.getElementById("printBtn");
  const archiveStatus = document.getElementById("archiveStatus");
  const params = new URLSearchParams(window.location.search);
  const archiveRender = params.get("archiveRender") === "1";

  if (printBtn) {
    printBtn.addEventListener("click", () => window.print());
  }

  const requestedActivityType = params.get("activityType") || "memory";
  const activityType = integration.resolveReportActivity(requestedActivityType, "memory").id;
  if (!archiveRender) {
    loadReview().catch(() => {
      root.innerHTML = '<section class="loading-card"><h2>正式报告读取失败</h2><p>请检查网络连接后刷新页面。</p></section>';
    });
  }

  async function loadReview() {
    const session = readStudentSession();
    if (session.isGuest) {
      renderReviewPage(buildReviewData(activityType, null, null, true));
      return;
    }
    const submissionId = params.get("submissionId") || "";
    const result = await window.BrainExperimentSubmission.getLatest(activityType, submissionId);
    if (!result?.ok || !result.state) {
      root.innerHTML = '<section class="loading-card"><h2>暂时无法生成正式报告</h2><p>没有找到已确认的正式提交，请返回实验页面重新提交案件。</p></section>';
      return;
    }
    renderReviewPage(buildReviewData(activityType, result.state, result.submission));
    if (activityType === "strategies") appendLearningDiagnosis();
    if (["memory", "nback", "interference", "strategies"].includes(activityType)) {
      archiveFormalReport(result.submission?.submissionId);
    }
  }

  async function archiveFormalReport(submissionId) {
    if (!submissionId || !window.BrainReportArchiveClient) return;
    if (archiveStatus) archiveStatus.textContent = "正在将报告存入平台…";
    const result = await window.BrainReportArchiveClient.generate(activityType, submissionId);
    if (archiveStatus) archiveStatus.textContent = result.ok
      ? "报告已存入平台，可在案件五查看"
      : "云端归档暂未完成，可在案件五重试";
  }

  function renderArchiveSubmission(submission) {
    if (!archiveRender || !submission || submission.experimentId !== activityType) return false;
    const state = Object.assign({}, submission.experimentResults || {}, {
      studentId: submission.studentId,
      studentName: submission.studentName,
      className: submission.className,
      groupName: submission.groupName,
      fields: submission.answers || {}
    });
    renderReviewPage(buildReviewData(activityType, state, submission));
    return Boolean(root.querySelector(".report-sheet"));
  }

  async function appendLearningDiagnosis() {
    const sheet = root && root.querySelector(".report-sheet");
    if (!sheet || !window.LearningDiagnosis) return;
    const section = document.createElement("section");
    section.className = "diagnosis-report-summary";
    section.innerHTML = '<h2 class="section-label">四次实验学习诊断</h2><div class="info-card"><p>正在核对四次实验记录...</p></div>';
    const footer = sheet.querySelector("footer");
    sheet.insertBefore(section, footer || null);
    const session = platform.identity.readStudentSession() || {};
    if (!session.sessionToken || session.isGuest) {
      section.innerHTML = '<h2 class="section-label">四次实验学习诊断</h2><div class="info-card"><p>登录正式学生账号后，可以在这里查看四次实验的综合诊断。</p></div>';
      return;
    }
    window.LearningDiagnosis.init({ experimentId: "strategies" });
    const result = await window.LearningDiagnosis.refresh();
    if (result?.diagnosis) {
      const report = result.diagnosis.report || {};
      section.innerHTML = `
        <h2 class="section-label">四次实验学习诊断</h2>
        <div class="diagnosis-review-card">
          <h3>你做得很好的地方</h3>
          ${renderDiagnosisItems(report.strengths)}
          <h3>四次实验中的进步</h3>
          ${renderDiagnosisItems(report.progress)}
          <h3>下一步行动建议</h3>
          ${renderDiagnosisItems(report.nextActions)}
          <a class="diagnosis-review-link" href="diagnosis.html" target="_blank" rel="noopener">查看完整学习诊断</a>
        </div>
      `;
      return;
    }
    const message = result?.eligibility?.eligible
      ? "四次实验已经完成，学习诊断正在后台整理。"
      : "完成全部四次实验后，这里会显示综合学习诊断。";
    section.innerHTML = `
      <h2 class="section-label">四次实验学习诊断</h2>
      <div class="info-card">
        <p>${esc(message)}</p>
        ${result?.eligibility?.eligible ? '<button class="diagnosis-review-retry" type="button">重新整理诊断</button>' : ""}
      </div>
    `;
    section.querySelector(".diagnosis-review-retry")?.addEventListener("click", async (event) => {
      event.currentTarget.disabled = true;
      event.currentTarget.textContent = "正在整理...";
      await window.LearningDiagnosis.requestGeneration();
      appendLearningDiagnosis();
      section.remove();
    });
  }

  function renderDiagnosisItems(items) {
    const values = Array.isArray(items) ? items.filter(Boolean).slice(0, 3) : [];
    return values.length
      ? `<ul>${values.map((item) => `<li>${esc(item)}</li>`).join("")}</ul>`
      : "<p>暂时没有足够记录。</p>";
  }

  function buildReviewData(activityType, suppliedState, submission, guestPreview = false) {
    const activity = integration.resolveReportActivity(activityType, "memory");
    const meta = {
      caseNo: activity.caseNo,
      caseTitle: activity.caseTitle,
      activityName: activity.activityName,
      type: activity.reportType
    };
    const storageKey = window.BrainPlatform.storage.migrateScopedJson(activity.storageKey);
    const state = suppliedState || readState(storageKey);
    const studentSession = readStudentSession();
    const fields = state.fields || {};
    const generatedAt = new Date().toLocaleString();
    const base = {
      activityType,
      storageKey,
      state,
      fields,
      meta,
      generatedAt,
      submission,
      guestPreview,
      identity: {
        studentName: state.studentName || studentSession.name,
        studentAge: state.studentAge,
        studentId: state.studentId || studentSession.studentId,
        className: state.className || studentSession.class,
        groupId: state.groupId,
        groupName: state.groupName || state.groupId || studentSession.group
      }
    };
    if (activityType === "poster") return buildPosterReview(base);
    return buildScienceReview(base);
  }

  function readState(storageKey) {
    try {
      return JSON.parse(localStorage.getItem(storageKey) || "null") || {};
    } catch (error) {
      return {};
    }
  }

  function readStudentSession() {
    return platform.identity.readStudentSession() || {};
  }

  function buildScienceReview(base) {
    const builders = {
      memory: buildMemoryContent,
      nback: buildNbackContent,
      interference: buildInterferenceContent,
      strategies: buildStrategiesContent
    };
    return Object.assign(base, builders[base.activityType](base.state, base.fields));
  }

  function buildMemoryContent(state, fields) {
    const materialLabel = getMemoryMaterialTypeLabel(fields.materialType || fields.material);
    const personalResult = getMemoryPersonalResult(state);
    const groupAverage = fields.groupAverageShortTermMemory || "";
    const summary = summarizeBy(state.records || [], "subject", (records) => {
      const capacities = records.map((record) => number(record.finalCapacity)).filter((value) => value > 0);
      const average = capacities.length ? round(avg(capacities), 1) : 0;
      return { value: average, label: average ? `${average} 个` : "暂未填写" };
    });
    const overall = fields.conclusionCapacity || averageFromSummary(summary);
    const questionThought = thinkingSummary(fields.question_individual || fields.question, fields.question_group);
    const hypothesisThought = thinkingSummary(fields.hypothesis_individual || fields.hypothesis, fields.hypothesis_group);
    const conclusionThought = thinkingSummary(fields.conclusion_individual || fields.finalConclusion, fields.conclusion_group || fields.finalConclusion_group);
    const reflectionThought = thinkingSummary(fields.reflection_individual || joinText([fields.designImprove, fields.teamwork, fields.inquiryReflection]), fields.reflection_group || joinText([fields.designImprove_group, fields.teamwork_group, fields.inquiryReflection_group]));
    return {
      steps: [
        ["提出问题", questionThought],
        ["作出假设", hypothesisThought],
        ["制定计划", `方法：${safe(fields.method)}；材料类别：${safe(materialLabel)}；起始长度：${safe(fields.startLength)}`],
        ["搜集证据", `已记录 ${count(state.records)} 条记忆任务数据。`],
        ["处理信息", fields.brainFinding],
        ["得出结论", conclusionThought]
      ],
      resultTitle: "短时记忆容量结果",
      chartRows: summary.length ? summary.map((item) => ({ label: item.name, value: item.value, text: item.label })) : [],
      resultHighlight: overall ? `我的短时记忆容量：约 ${overall} 个信息单位` : "",
      evidence: [
        ["研究问题", questionThought],
        ["研究假设", hypothesisThought],
        ["实验材料类别", materialLabel],
        ["实验计划", `采用${safe(fields.method)}，材料类别为${safe(materialLabel)}，每位参与者测量${safe(fields.trialsPerParticipant)}次。`],
        ["三人成绩", `本人：${safe(personalResult)}；组员1：${safe(fields.teammate1Result)}；组员2：${safe(fields.teammate2Result)}`],
        ["小组平均长度", groupAverage],
        ["头环观察记录", fields.brainFinding]
      ],
      conclusion: joinText([conclusionThought, reflectionThought])
    };
  }

  function buildNbackContent(state, fields) {
    const materialLabel = getNbackMaterialTypeLabel(fields.materialType || fields.stimulusMaterial);
    const teammateSummary = formatNbackTeammateResults(fields);
    const summary = summarizeBy(state.testRuns || [], "condition", (records) => {
      const accuracy = records.map((record) => number(record.accuracy)).filter((value) => value >= 0);
      const average = accuracy.length ? Math.round(avg(accuracy)) : 0;
      return { value: average, label: average ? `${average}%` : "暂未填写" };
    });
    const questionThought = thinkingSummary(fields.question_individual || fields.researchQuestion, fields.question_group || fields.researchQuestion_group);
    const hypothesisThought = thinkingSummary(fields.hypothesis_individual || fields.hypothesis, fields.hypothesis_group);
    const conclusionThought = thinkingSummary(fields.conclusion_individual || fields.conclusion, joinText([fields.conclusion_group, fields.conclusionSupported_group]));
    const reflectionThought = thinkingSummary(fields.reflection_individual || joinText([fields.improvement, fields.persuasiveness]), fields.reflection_group || joinText([fields.improvement_group, fields.persuasiveness_group]));
    return {
      steps: [
        ["提出问题", questionThought],
        ["作出假设", hypothesisThought],
        ["制定计划", `自变量：${safe(fields.independentVariable)}；材料类别：${safe(materialLabel)}；设计：${safe(fields.experimentDesign)}`],
        ["搜集证据", `已记录 ${count(state.testRuns)} 条 N-back 测试数据。`],
        ["处理信息", fields.headbandObservation],
        ["得出结论", conclusionThought]
      ],
      resultTitle: "N-back 正确率结果",
      chartRows: summary.length ? summary.map((item) => ({ label: item.name, value: item.value, text: item.label })) : [],
      resultHighlight: `假设判断：${safe(fields.conclusionSupported)}`,
      evidence: [
        ["研究问题", questionThought],
        ["研究假设", hypothesisThought],
        ["实验材料类别", materialLabel],
        ["N-back 条件设计", `刺激材料类别：${safe(materialLabel)}；刺激间隔：${safe(fields.stimulusInterval)} 秒。`],
        ["其他组员实验结果", teammateSummary],
        ["头环观察记录", fields.headbandObservation]
      ],
      conclusion: joinText([conclusionThought, reflectionThought])
    };
  }

  function buildInterferenceContent(state, fields) {
    const teammateSummary = formatInterferenceTeammateResults(fields);
    const summary = summarizeBy(state.records || [], "condition", (records) => {
      const accuracy = records.map((record) => number(record.accuracy)).filter((value) => value >= 0);
      const average = accuracy.length ? Math.round(avg(accuracy)) : 0;
      return { value: average, label: average ? `${average}%` : "暂未填写" };
    });
    const questionThought = thinkingSummary(fields.question_individual || joinText([fields.lifeFactors, fields.materialFactors]), fields.question_group || joinText([fields.lifeFactors_group, fields.materialFactors_group, fields.question || fields.questionFactor]));
    const hypothesisThought = thinkingSummary(fields.hypothesis_individual || fields.hypothesis, fields.hypothesis_group);
    const conclusionThought = thinkingSummary(fields.conclusion_individual || fields.conclusion, joinText([fields.conclusion_group, fields.support_group, fields.credibility_group]));
    const reflectionThought = thinkingSummary(fields.reflection_individual || joinText([fields.strengths, fields.improvements, fields.learningInsight]), fields.reflection_group || joinText([fields.strengths_group, fields.improvements_group, fields.learningInsight_group]));
    return {
      steps: [
        ["提出问题", questionThought],
        ["作出假设", hypothesisThought],
        ["制定计划", `探究因素：${safe(fields.factor)}；难度：${safe(fields.difficulty)}；记忆时间：${safe(fields.memorySeconds)} 秒。`],
        ["搜集证据", `已记录 ${count(state.records)} 条长时记忆干扰数据。`],
        ["处理信息", fields.headband],
        ["得出结论", conclusionThought]
      ],
      resultTitle: "不同干扰条件下的记忆结果",
      chartRows: summary.length ? summary.map((item) => ({ label: item.name, value: item.value, text: item.label })) : [],
      resultHighlight: `最可能影响长时记忆的因素：${safe(fields.factor)}`,
      evidence: [
        ["研究问题", questionThought],
        ["研究假设", hypothesisThought],
        ["干扰因素选择", fields.factor],
        ["其他组员实验结果", teammateSummary],
        ["头环观察记录", fields.headband]
      ],
      conclusion: joinText([conclusionThought, reflectionThought])
    };
  }

  function buildStrategiesContent(state, fields) {
    const records = Array.isArray(state.records) ? state.records : [];
    const grouped = new Map();
    records.forEach((record) => {
      const round = number(record.round);
      const stage = number(record.stage);
      const roundLabel = record.roundLabel || (round === 1 ? "第一轮" : round === 2 ? "第二轮" : "历史记录");
      const stageLabel = record.stageLabel || (stage === 1 ? "第一阶段" : stage === 2 ? "第二阶段" : "未标记阶段");
      const strategy = safe(record.strategy);
      const key = round && stage ? `${round}-${stage}` : `legacy-${stage}-${strategy}`;
      if (!grouped.has(key)) grouped.set(key, { key, round, stage, roundLabel, stageLabel, strategy, records: [] });
      grouped.get(key).records.push(record);
    });
    const summary = Array.from(grouped.values()).sort((left, right) => (left.round - right.round) || (left.stage - right.stage)).map((group) => {
      const accuracy = group.records.map((record) => number(record.accuracy)).filter((value) => value >= 0);
      const correct = group.records.map((record) => number(record.correctCount)).filter((value) => value >= 0);
      const averageAccuracy = accuracy.length ? Math.round(avg(accuracy)) : 0;
      const averageCorrect = correct.length ? round(avg(correct), 1) : 0;
      return Object.assign(group, {
        value: averageAccuracy,
        label: `${group.roundLabel}·${group.stageLabel}·${group.strategy}`,
        resultText: `平均正确数 ${averageCorrect}，平均回忆率 ${averageAccuracy}%`
      });
    });
    const completed = new Set(records.filter((record) => record.round && record.stage).map((record) => `${number(record.round)}-${number(record.stage)}`));
    const completionText = ["1-1", "1-2", "2-1", "2-2"].every((key) => completed.has(key)) ? "四个组合均已完成" : `已完成 ${completed.size}/4 个组合`;
    const materialLabels = { word: "英文单词", poem: "古诗", idiom: "中文词语/成语", code: "数字字母串（历史记录）", formula: "公式（历史记录）" };
    const roundPlanText = (round) => {
      const prefix = `round${round}`;
      const type = fields[`${prefix}MaterialType`] || fields.materialType || "";
      const low = number(fields[`${prefix}LowCount`] ?? fields.lowCount);
      const mid = number(fields[`${prefix}MidCount`] ?? fields.midCount);
      const high = number(fields[`${prefix}HighCount`] ?? fields.highCount);
      const strategy = round === 1 ? fields.strategy1 : fields.strategy2;
      return `第${round === 1 ? "一" : "二"}轮：简单复述 vs ${safe(strategy)}；材料：${materialLabels[type] || safe(type)}；初级${low}题、中级${mid}题、高级${high}题，共${low + mid + high}题`;
    };
    const experimentPlan = `${roundPlanText(1)}；${roundPlanText(2)}`;
    const groupedResult = summary.map((item) => `${item.label}：${item.resultText}`).join("；") || "暂未填写";
    const brainstormThought = thinkingSummary(fields.brainstormIndividual || fields.question_individual, fields.brainstormGroup || fields.question_group);
    const researchQuestion = safe(fields.question || (fields.questionStrategy ? `${fields.questionStrategy}可以改善长时记忆` : ""));
    const questionThought = joinText([
      brainstormThought ? `头脑风暴：${brainstormThought}` : "",
      researchQuestion ? `研究问题（小组）：${researchQuestion}` : ""
    ]);
    const hypothesisThought = thinkingSummary(fields.hypothesis_individual || joinText([fields.hypothesis1, fields.hypothesis2]), fields.hypothesis_group || joinText([fields.hypothesis1_group, fields.hypothesis2_group]));
    const conclusionThought = thinkingSummary(fields.conclusion_individual || fields.conclusion, fields.conclusion_group);
    const reflectionThought = thinkingSummary(fields.reflection_individual || joinText([fields.designImprove, fields.surprise, fields.applicability]), fields.reflection_group || joinText([fields.designImprove_group, fields.surprise_group, fields.applicability_group]));
    return {
      steps: [
        ["提出问题", questionThought],
        ["作出假设", hypothesisThought],
        ["制定计划", `${experimentPlan}；找不同 ${safe(fields.puzzleSeconds)} 秒；测试 ${safe(fields.testSeconds)} 秒。`],
        ["搜集证据", `${completionText}，共记录 ${count(records)} 条记忆策略数据。`],
        ["处理信息", fields.headband],
        ["得出结论", conclusionThought]
      ],
      resultTitle: "不同策略下的记忆表现",
      chartRows: summary.length ? summary.map((item) => ({ label: item.label, value: item.value, text: `${item.value}%` })) : [],
      resultHighlight: experimentPlan,
      evidence: [
        ["头脑风暴", brainstormThought],
        ["研究问题（小组）", researchQuestion],
        ["研究假设", hypothesisThought],
        ["实验计划", experimentPlan],
        ["组合完成情况", completionText],
        ["轮次阶段结果", groupedResult],
        ["头环观察记录", fields.headband]
      ],
      conclusion: joinText([conclusionThought, reflectionThought])
    };
  }

  function buildPosterReview(base) {
    const fields = base.fields;
    const validQuestions = (base.state.questions || []).filter((item) => hasText(item.question) || hasText(item.answer));
    const qaRecords = Array.isArray(base.state.qaRecords) && base.state.qaRecords.length
      ? base.state.qaRecords
      : [{ question: fields.askedQuestions || "", answer: fields.answers || "" }];
    const qaText = qaRecords.map((item, index) => [
      `问题${index + 1}：${safe(item.question)}`,
      `回答${index + 1}：${safe(item.answer)}`
    ].join("\n")).join("\n");
    return Object.assign(base, {
      steps: [
        ["初步方案", fields.researchPlan],
        ["研究问题", fields.researchQuestion],
        ["研究假设", fields.hypothesis],
        ["制作记录", joinText([fields.layoutSketch, fields.visualPlan])],
        ["分享交流", joinText([fields.speakingPoints, qaText])],
        ["总结反思", joinText([fields.reflectionGain, fields.reflectionImprove, fields.teamReflection, fields.nextUse])]
      ],
      resultTitle: "作品回顾",
      chartRows: [],
      resultHighlight: `数据呈现方式：${safe(fields.dataDisplay)}；主要图表类型：${safe(fields.chartPlan)}`,
      evidence: [
        ["研究问题", fields.researchQuestion],
        ["研究假设", fields.hypothesis],
        ["研究计划", fields.researchPlan],
        ["研究结论", fields.conclusion],
        ["海报制作记录", fields.layoutSketch],
        ["AI 辅助建议记录", fields.aiSupport],
        ["分享交流记录", joinText([fields.presenter, fields.presenterStudentId, fields.speakingPoints, qaText])],
        ["提问交流记录", validQuestions.map((item) => `${safe(item.group)}：${safe(item.question)} / ${safe(item.answer)}`).join("\n")]
      ],
      conclusion: joinText([fields.reflectionGain, fields.reflectionImprove, fields.teamReflection, fields.nextUse])
    });
  }

  function renderReviewPage(reviewData) {
    if (!root) return;
    const html = reviewData.meta.type === "poster" ? renderPosterReport(reviewData) : renderScienceReport(reviewData);
    root.innerHTML = html;
  }

  function renderScienceReport(data) {
    return renderReportShell(data, "实验结果", renderResultSection(data));
  }

  function renderPosterReport(data) {
    return renderReportShell(data, "作品回顾", renderResultSection(data));
  }

  function renderReportShell(data, resultLabel, resultHtml) {
    return `
      <article class="report-sheet">
        ${data.guestPreview ? '<div class="info-card"><strong>游客体验报告：此报告来自本地状态，不属于正式研究数据。</strong></div>' : ""}
        ${renderHeader(data)}
        <section>
          <h2 class="section-label">档案信息</h2>
          <div class="archive-grid">
            ${renderIdentity(data)}
            <div class="info-card activity-card">
              <small>参与活动</small>
              <h2>${esc(data.meta.caseNo)}：${esc(data.meta.caseTitle)}</h2>
              <p>${esc(data.meta.activityName)}</p>
            </div>
          </div>
        </section>
        <section>
          <h2 class="section-label">探究历程</h2>
          ${renderTimeline(data.steps)}
        </section>
        <section>
          <h2 class="section-label">${esc(resultLabel)}</h2>
          ${resultHtml}
        </section>
        <section>
          <h2 class="section-label">${data.meta.type === "poster" ? "我的活动收获" : "我的科学结论"}</h2>
          <div class="conclusion-card"><span class="stamp">${data.meta.type === "poster" ? "创作完成" : "探究完成"}</span><p>${esc(safe(data.conclusion))}</p></div>
        </section>
        <section>
          <h2 class="section-label">学习足迹</h2>
          ${renderFootprints(data)}
        </section>
        <footer class="footer-note">
          <p>由 ZJU BIElab 制作&nbsp;&nbsp;揭秘大脑密码，塑造无限可能</p>
          <div class="quote-note">每一次探究，都是一次发现</div>
        </footer>
      </article>
    `;
  }

  function renderHeader(data) {
    return `
      <header class="report-header">
        <div class="photo-card">
          <div class="brain-plate">${brainSvg()}</div>
          <span class="case-stamp">CASE FILE</span>
        </div>
        <div class="report-title">
          <span class="brand-strip">记忆侦探社</span>
          <h1>记忆侦探报告</h1>
          <p>我的科学探究档案</p>
        </div>
        <aside class="meta-slip">
          <p><span>报告生成时间</span><strong>${esc(data.generatedAt)}</strong></p>
          <p><span>探索编号</span><strong>${esc(createCaseId(data))}</strong></p>
        </aside>
      </header>
    `;
  }

  function renderIdentity(data) {
    const info = data.identity;
    return `
      <div class="info-card">
        <div class="info-item"><span>学号</span><strong>${esc(safe(info.studentId))}</strong></div>
        <div class="info-item"><span>姓名</span><strong>${esc(safe(info.studentName))}</strong></div>
        <div class="info-item"><span>班级</span><strong>${esc(safe(info.className))}</strong></div>
        <div class="info-item"><span>小组</span><strong>${esc(safe(info.groupName || info.groupId))}</strong></div>
      </div>
    `;
  }

  function renderTimeline(steps) {
    return `<div class="timeline">${steps.map((step, index) => `
      <article class="timeline-item">
        <span class="timeline-index">${index + 1}</span>
        <h3>${esc(step[0])}</h3>
        <p>${esc(safe(step[1]))}</p>
      </article>
    `).join("")}</div>`;
  }

  function renderResultSection(data) {
    return `
      <div class="result-grid">
        <div class="result-card">
          <h3>${esc(data.resultTitle)}</h3>
          ${data.chartRows.length ? renderBarChart(data.chartRows) : `<p>${esc(safe(data.resultHighlight))}</p>`}
          <div class="result-highlight">${esc(safe(data.resultHighlight))}</div>
        </div>
        <div class="result-card">
          <h3>${data.meta.type === "poster" ? "关键作品证据" : "关键探究证据"}</h3>
          <div class="evidence-list">
            ${(data.evidence || []).map((item) => `<div class="evidence-card"><span>${esc(item[0])}</span><strong>${esc(safe(item[1]))}</strong></div>`).join("")}
          </div>
        </div>
      </div>
    `;
  }

  function renderBarChart(rows) {
    const maxValue = Math.max(100, ...rows.map((row) => number(row.value)));
    return `<div class="bar-chart">${rows.slice(0, 8).map((row) => {
      const width = Math.max(4, Math.round((number(row.value) / maxValue) * 100));
      return `<div class="bar-row"><span>${esc(row.label)}</span><div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div><strong>${esc(row.text)}</strong></div>`;
    }).join("")}</div>`;
  }

  function renderFootprints(data) {
    const state = data.state || {};
    const fields = data.fields || {};
    const hasRecords = count(state.records) + count(state.testRuns) > 0;
    const hasHeadband = hasText(fields.brainFinding) || hasText(fields.headbandObservation) || hasText(fields.headband);
    const items = [
      ["01", "完成了探究步骤"],
      ["02", hasRecords ? "记录了实验数据" : "整理了活动记录"],
      ["03", "绘制了结果图表"],
      ["04", hasHeadband ? "观察了头环数据" : "梳理了关键证据"],
      ["05", "形成了科学结论"],
      ["06", "进行了交流反思"]
    ];
    return `<div class="footprints">${items.map((item) => `<div class="footprint-card"><strong>${item[0]}</strong><span>${esc(item[1])}</span></div>`).join("")}</div>`;
  }

  function summarizeBy(records, key, project) {
    const groups = new Map();
    records.forEach((record) => {
      const name = safe(record[key] || record.nLevel || record.condition || record.strategy || record.participant);
      if (!groups.has(name)) groups.set(name, []);
      groups.get(name).push(record);
    });
    return Array.from(groups.entries()).map(([name, items]) => Object.assign({ name }, project(items)));
  }

  function averageFromSummary(summary) {
    const values = summary.map((item) => number(item.value)).filter((value) => value > 0);
    return values.length ? round(avg(values), 1) : "";
  }

  function createCaseId(data) {
    const id = safe(data.identity.studentId).replace(/\s+/g, "") || "NOID";
    const date = new Date();
    const y = String(date.getFullYear()).slice(2);
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${data.activityType.toUpperCase()}-${y}${m}${d}-${id}`;
  }

  function brainSvg() {
    return '<svg viewBox="0 0 180 140" aria-hidden="true"><path d="M54 92c-18-4-28-17-26-34 2-16 15-25 28-24 7-15 30-17 41-6 13-10 35-2 38 14 18 4 25 21 18 36-6 13-19 18-33 15-11 14-33 15-45 2-7 2-14 1-21-3Z" fill="none" stroke="#35a9ff" stroke-width="6" stroke-linejoin="round"/><path d="M62 39c-6 12 5 19 19 17m16-29c-8 17 4 25 18 23m-65 24c16-7 28-4 36 10m10-29c16 1 25 11 25 27m-42-20c-2 18 8 29 24 34" fill="none" stroke="#7fe3ff" stroke-width="4" stroke-linecap="round"/><circle cx="135" cy="43" r="6" fill="#f4c45d"/><circle cx="39" cy="74" r="5" fill="#f4c45d"/></svg>';
  }

  function getMemoryMaterialTypeLabel(type) {
    return {
      number: "数字",
      letter: "英文大写字母",
      chinese: "汉字",
      shape: "图形",
      数字: "数字",
      字母: "英文大写字母",
      英文大写字母: "英文大写字母",
      汉字: "汉字",
      图形: "图形"
    }[type] || "数字";
  }

  function getNbackMaterialTypeLabel(type) {
    return {
      image: "图片",
      number: "数字",
      letter: "英文大写字母",
      chinese: "汉字",
      图片: "图片",
      图形: "图片",
      数字: "数字",
      字母: "英文大写字母",
      英文大写字母: "英文大写字母",
      汉字: "汉字"
    }[type] || "图片";
  }

  function getMemoryPersonalResult(state) {
    const records = Array.isArray(state.records) ? state.records : [];
    const byRun = new Map();
    records.forEach((record) => {
      const key = `${record.subject}|${record.runNumber}`;
      byRun.set(key, number(record.finalCapacity ?? record.capacityAfterTrial));
    });
    const values = Array.from(byRun.values()).filter((value) => value > 0);
    return values.length ? round(avg(values), 1) : "";
  }

  function formatNbackTeammateResults(fields) {
    const formatMember = (index) => {
      const id = fields[`teammate${index}Id`];
      const material = getNbackMaterialTypeLabel(fields[`teammate${index}MaterialType`]);
      const accuracy = fields[`teammate${index}AverageAccuracy`];
      const missRate = fields[`teammate${index}AverageMissRate`];
      const legacy = fields[`teammate${index}Result`];
      if (hasText(id) || hasText(accuracy) || hasText(missRate)) {
        return `组员${index}：编号${safe(id)}，材料${safe(material)}，平均正确率${safe(accuracy)}%，平均漏答率${safe(missRate)}%`;
      }
      if (hasText(legacy)) return `组员${index}：${safe(legacy)}`;
      return "";
    };
    return joinText([formatMember(1), formatMember(2)]);
  }

  function formatInterferenceTeammateResults(fields) {
    const labels = { retroactive: "倒摄干扰", similarity: "相似性干扰", emotion: "情绪状态干扰" };
    const source = Array.isArray(fields.otherMemberResults) ? fields.otherMemberResults : [];
    const formatMember = (index) => {
      const item = source[index - 1] || {};
      const legacyId = fields[`teammate${index}Id`];
      const legacyResult = fields[`teammate${index}Result`];
      const memberId = item.memberId || legacyId;
      const factor = labels[item.interferenceFactor] || item.interferenceFactor || "";
      const material = item.materialType || "";
      const score = item.averageScore;
      const accuracy = item.averageAccuracy;
      if (hasText(memberId) || hasText(factor) || hasText(material) || hasText(score) || hasText(accuracy)) {
        return `组员${index}：编号${safe(memberId)}，干扰因素${safe(factor)}，实验材料${safe(material)}，平均得分${safe(score)}，平均正确率${safe(accuracy)}%`;
      }
      if (hasText(legacyResult)) return `组员${index}：${safe(legacyResult)}`;
      return "";
    };
    return joinText([formatMember(1), formatMember(2)]);
  }

  function thinkingSummary(individual, group) {
    return joinText([
      `学生个人回答：${safe(individual)}`,
      `小组讨论结果：${safe(group)}`
    ]);
  }

  function safe(value) {
    if (value === null || value === undefined || value === "") return "暂未填写";
    return String(value);
  }

  function hasText(value) {
    return value !== null && value !== undefined && String(value).trim() !== "";
  }

  function joinText(items) {
    return items.filter(hasText).join("\n") || "暂未填写";
  }

  function count(items) {
    return Array.isArray(items) ? items.length : 0;
  }

  function number(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function avg(values) {
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  }

  function round(value, digits) {
    const factor = Math.pow(10, digits || 0);
    return Math.round(value * factor) / factor;
  }

  function esc(value) {
    return safe(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[char]));
  }

  window.buildReviewData = buildReviewData;
  window.renderReviewPage = renderReviewPage;
  window.renderScienceReport = renderScienceReport;
  window.renderPosterReport = renderPosterReport;
  window.BrainReportArchive = Object.freeze({ render: renderArchiveSubmission });
})();
