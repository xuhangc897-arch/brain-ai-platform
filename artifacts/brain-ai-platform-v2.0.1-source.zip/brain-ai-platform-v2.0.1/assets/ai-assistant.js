(function () {
  "use strict";

  const platform = window.BrainPlatform;
  const integration = window.BrainExperimentIntegration;
  const AI_API_ENDPOINT = platform.config.endpoints.aiChat;
  const CONTEXT_KEY = platform.storage.migrateScopedJson(platform.config.storageKeys.inquiryContext);
  const LOG_KEY = platform.storage.migrateScopedJson(platform.config.storageKeys.aiChatLogs);
  const MAX_QUESTION_LENGTH = 500;
  const DRAG_MARGIN = 12;
  const DRAG_THRESHOLD = 5;

  const root = document.createElement("div");
  root.className = "ai-assistant";
  root.innerHTML = `
    <div class="ai-hint" aria-hidden="true">我是你的AI侦探助手，有什么问题都可以问我噢！</div>
    <button class="ai-toggle" type="button" aria-label="打开 AI 助手">
      <span class="ai-brain-wrap" aria-hidden="true">
        <svg class="ai-brain-icon" viewBox="0 0 64 64" focusable="false">
          <path class="ai-brain-fill" d="M23.6 49.8c-6.3-.7-11-5.5-11-11.8 0-2.6.8-5 2.2-7-1.3-5.8 2.4-11.5 8.2-12.3 2-4.1 6-6.6 10.6-6.6 5.7 0 10.5 3.9 11.6 9.3 4.6 1.5 7.8 5.7 7.8 10.8 0 5.3-3.5 9.8-8.3 11.1-1.7 4.1-5.7 7-10.5 7-1.7 0-3.4-.4-4.8-1.1-1.7.8-3.7 1.1-5.8.6Z"/>
          <path d="M23.1 19.1c-1.4 2.5-1.3 5.8.5 8.3M34 12.4c-2.6 2.2-3.5 5.8-2.2 8.9M45 21.6c-3.4-.2-6.6 1.5-8.2 4.4M15.1 31.1c2.5-.7 5.3-.1 7.3 1.8M29.1 48.9c1.6-2.5 1.8-5.7.5-8.3M44.7 43.3c-.6-3.4-2.9-6-6-7.1M24.2 32.7c2.3-2.1 5.8-2.6 8.6-1.2" />
          <circle cx="39.8" cy="31.9" r="2.1" />
          <circle cx="23.8" cy="39.1" r="2" />
        </svg>
        <span class="ai-brain-mark">?</span>
      </span>
      <span class="ai-toggle-label">点击与 AI 对话</span>
    </button>
    <section class="ai-panel" aria-label="AI 学习助手">
      <header class="ai-head">
        <div class="ai-heading">
          <p class="ai-title">AI 学习助手</p>
          <p class="ai-subtitle">只给提示，不代写答案</p>
        </div>
        <div class="ai-head-actions" aria-label="AI 对话记录操作">
          <button class="ai-close" type="button" aria-label="关闭 AI 助手">×</button>
        </div>
      </header>
      <div class="ai-messages" aria-live="polite"></div>
      <form class="ai-form">
        <p class="ai-assessment-notice" data-ai-assessment-notice hidden>知识验证和问卷需要独立完成，完成后可继续使用 AI 助手。</p>
        <div class="ai-voice-row">
          <button class="ai-voice" type="button" data-ai-voice aria-label="使用语音输入问题">🎙 语音提问</button>
          <p class="ai-voice-status" data-ai-voice-status role="status" aria-live="polite"></p>
        </div>
        <input class="ai-input" type="text" maxlength="${MAX_QUESTION_LENGTH}" placeholder="输入你的问题..." autocomplete="off" />
        <button class="ai-send" type="submit">发送</button>
      </form>
    </section>
  `;

  const toggle = root.querySelector(".ai-toggle");
  const close = root.querySelector(".ai-close");
  const messages = root.querySelector(".ai-messages");
  const form = root.querySelector(".ai-form");
  const input = root.querySelector(".ai-input");
  const send = root.querySelector(".ai-send");
  const voiceButton = root.querySelector("[data-ai-voice]");
  const voiceStatus = root.querySelector("[data-ai-voice-status]");
  const assessmentNotice = root.querySelector("[data-ai-assessment-notice]");
  const panel = root.querySelector(".ai-panel");
  const head = root.querySelector(".ai-head");
  let voiceSession = null;
  let voiceState = "idle";
  let assessmentLocked = false;
  let requestPending = false;

  function installDraggable(options) {
    const { dragRoot, visibleWhenClosed, visibleWhenOpen, handles } = options;
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;
    let didDrag = false;
    let suppressClick = false;

    function isInteractiveTarget(target) {
      return Boolean(target.closest("button, input, textarea, select, a, [data-no-drag]"));
    }

    function getVisibleElement() {
      return dragRoot.classList.contains("is-open") ? visibleWhenOpen : visibleWhenClosed;
    }

    function getVisibleRect() {
      const visible = getVisibleElement();
      return visible.getBoundingClientRect();
    }

    function clampPosition(left, top) {
      const visible = getVisibleElement();
      const width = visible.offsetWidth || visible.getBoundingClientRect().width || 1;
      const height = visible.offsetHeight || visible.getBoundingClientRect().height || 1;
      const maxLeft = Math.max(DRAG_MARGIN, window.innerWidth - width - DRAG_MARGIN);
      const maxTop = Math.max(DRAG_MARGIN, window.innerHeight - height - DRAG_MARGIN);
      return {
        left: Math.min(Math.max(left, DRAG_MARGIN), maxLeft),
        top: Math.min(Math.max(top, DRAG_MARGIN), maxTop)
      };
    }

    function applyPosition(left, top) {
      const next = clampPosition(left, top);
      dragRoot.classList.add("is-dragged");
      dragRoot.style.left = `${next.left}px`;
      dragRoot.style.top = `${next.top}px`;
      dragRoot.style.right = "auto";
      dragRoot.style.bottom = "auto";
    }

    function syncCurrentPosition() {
      const rect = getVisibleRect();
      applyPosition(rect.left, rect.top);
    }

    function onPointerMove(event) {
      if (event.pointerId !== pointerId) return;
      const deltaX = event.clientX - startX;
      const deltaY = event.clientY - startY;
      if (!didDrag && Math.hypot(deltaX, deltaY) < DRAG_THRESHOLD) return;
      didDrag = true;
      event.preventDefault();
      applyPosition(startLeft + deltaX, startTop + deltaY);
    }

    function onPointerUp(event) {
      if (event.pointerId !== pointerId) return;
      pointerId = null;
      dragRoot.classList.remove("is-dragging");
      try {
        event.currentTarget.releasePointerCapture(event.pointerId);
      } catch (error) {
        // Pointer capture may already be released by the browser.
      }
      if (didDrag) {
        suppressClick = true;
        window.setTimeout(() => {
          suppressClick = false;
        }, 0);
      }
    }

    handles.forEach((handle) => {
      handle.setAttribute("data-drag-handle", "");
      handle.addEventListener("pointerdown", (event) => {
        if (event.button !== undefined && event.button !== 0) return;
        if (handle !== visibleWhenClosed && isInteractiveTarget(event.target)) return;
        const rect = getVisibleRect();
        pointerId = event.pointerId;
        startX = event.clientX;
        startY = event.clientY;
        startLeft = rect.left;
        startTop = rect.top;
        didDrag = false;
        dragRoot.classList.add("is-dragging");
        handle.setPointerCapture(event.pointerId);
      });
      handle.addEventListener("pointermove", onPointerMove);
      handle.addEventListener("pointerup", onPointerUp);
      handle.addEventListener("pointercancel", onPointerUp);
      handle.addEventListener("click", (event) => {
        if (!suppressClick) return;
        event.preventDefault();
        event.stopImmediatePropagation();
      }, true);
    });

    window.addEventListener("resize", () => {
      if (!dragRoot.classList.contains("is-dragged")) return;
      const rect = getVisibleRect();
      applyPosition(rect.left, rect.top);
    });

    return {
      clamp() {
        if (!dragRoot.classList.contains("is-dragged")) return;
        window.requestAnimationFrame(() => {
          const rect = getVisibleRect();
          applyPosition(rect.left, rect.top);
        });
      }
    };
  }

  const dragControls = installDraggable({
    dragRoot: root,
    visibleWhenClosed: toggle,
    visibleWhenOpen: panel,
    handles: [toggle, head]
  });

  function getEndpoint() {
    return window.BRAIN_AI_ENDPOINT || AI_API_ENDPOINT;
  }

  function readJson(key, fallback) {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "null");
      return value || fallback;
    } catch (error) {
      console.warn("[AI Assistant] localStorage parse failed:", {
        key,
        name: (error && error.name) || "Error"
      });
      return fallback;
    }
  }

  function readIdentity() {
    const identity = readJson(CONTEXT_KEY, {});
    const student = platform.identity.readStudentSession() || {};
    return {
      studentName: identity.studentName || student.name || student.studentName || "",
      studentAge: identity.studentAge || "",
      studentId: identity.studentId || student.studentId || "",
      className: identity.className || student.class || student.className || "",
      groupId: identity.groupId || identity.groupName || student.group || student.groupName || ""
    };
  }

  function readLogs() {
    const logs = readJson(LOG_KEY, []);
    return Array.isArray(logs) ? logs : [];
  }

  function saveLogs(logs) {
    localStorage.setItem(LOG_KEY, JSON.stringify(logs));
  }

  function getText(selector) {
    const node = document.querySelector(selector);
    return node ? node.textContent.replace(/\s+/g, " ").trim() : "";
  }

  function getCurrentStep() {
    const activeProgress = getText(".progress-step.is-active");
    if (activeProgress) return activeProgress;
    const panelTitle = getText(".panel-head h2");
    if (panelTitle) return panelTitle;
    const scienceTitle = getText("#scienceTitle h2");
    if (scienceTitle) return scienceTitle;
    return "未识别当前步骤";
  }

  function isAssessmentStep(value) {
    return /(?:^|\s)posttest(?:\s|$)|侦探小结|知识后测|知识验证|调查问卷/.test(String(value || ""));
  }

  function getExperimentName() {
    const title = document.title.replace(/\s+/g, " ").trim();
    const headerTitle = getText(".brand-title h1") || getText("h1") || getText(".ai-page-title");
    return headerTitle || title || "脑育智能体学习平台";
  }

  function getContext(question) {
    return {
      ...readIdentity(),
      question,
      pageTitle: document.title || "",
      experimentName: getExperimentName(),
      currentStep: getCurrentStep(),
      path: location.pathname
    };
  }

  function updateControls() {
    const voiceBusy = ["preparing", "recording", "finalizing"].includes(voiceState);
    const voiceAvailable = Boolean(window.VoiceAssistant?.createSession);
    input.disabled = assessmentLocked || requestPending;
    send.disabled = assessmentLocked || requestPending || voiceBusy;
    voiceButton.disabled = assessmentLocked || requestPending || !voiceAvailable || ["preparing", "finalizing"].includes(voiceState);
    voiceButton.textContent = voiceState === "recording" ? "■ 停止录音" : "🎙 语音提问";
    voiceButton.setAttribute("aria-label", voiceState === "recording" ? "停止语音输入" : "使用语音输入问题");
  }

  function setAssessmentLock(nextLocked) {
    assessmentLocked = Boolean(nextLocked);
    assessmentNotice.hidden = !assessmentLocked;
    if (assessmentLocked && voiceSession) voiceSession.cancel();
    updateControls();
    return assessmentLocked;
  }

  function syncAssessmentLock(stepId) {
    return setAssessmentLock(stepId === "posttest" || isAssessmentStep(getCurrentStep()));
  }

  function appendVoiceQuestion(text) {
    const nextText = String(text || "").trim();
    if (!nextText) return;
    const joined = input.value.trim() ? `${input.value.trim()} ${nextText}` : nextText;
    input.value = joined.slice(0, MAX_QUESTION_LENGTH);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    if (joined.length > MAX_QUESTION_LENGTH) {
      voiceStatus.textContent = `语音内容已达到 ${MAX_QUESTION_LENGTH} 字上限，请检查后发送。`;
    }
  }

  function ensureVoiceSession() {
    if (voiceSession) return voiceSession;
    if (!window.VoiceAssistant?.createSession) return null;
    voiceSession = window.VoiceAssistant.createSession({
      onStateChange(nextState) {
        voiceState = nextState;
        if (nextState === "preparing") {
          voiceStatus.textContent = "正在准备麦克风，请稍候，暂时不要说话。";
        } else if (nextState === "recording") {
          voiceStatus.textContent = "可以说话了，说完请点击“停止录音”。";
        } else if (nextState === "finalizing") {
          voiceStatus.textContent = "正在生成文字，请稍候。";
        } else if (nextState === "completed") {
          voiceStatus.textContent = input.value.trim()
            ? "语音已转成文字，请检查后再发送。"
            : "没有识别到文字，请重新录音。";
        } else if (nextState === "idle") {
          voiceStatus.textContent = "";
        }
        updateControls();
      },
      onPartial(text) {
        if (text) voiceStatus.textContent = `正在识别：${text}`;
      },
      onFinal(text) {
        appendVoiceQuestion(text);
      },
      onError(message, error) {
        console.warn("[AI Assistant] voice input failed:", {
          name: error?.name || "Error"
        });
        voiceStatus.textContent = message || "语音识别失败，请稍后重试。";
      }
    });
    return voiceSession;
  }

  async function toggleVoiceInput() {
    if (syncAssessmentLock()) return;
    const session = ensureVoiceSession();
    if (!session || !session.isSupported()) {
      voiceStatus.textContent = "当前浏览器不支持语音识别助手。";
      updateControls();
      return;
    }
    if (session.getState() === "recording") {
      session.stop();
      return;
    }
    await session.start();
  }

  function appendMessage(role, text) {
    const bubble = document.createElement("div");
    bubble.className = `ai-message ${role === "user" ? "is-user" : "is-ai"}`;
    bubble.textContent = text;
    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
    return bubble;
  }

  function renderHistory() {
    messages.innerHTML = "";
    const identity = readIdentity();
    const logs = readLogs().filter((log) => {
      if (identity.studentId && log.studentId && log.studentId !== identity.studentId) return false;
      return log.path === location.pathname;
    });

    if (!logs.length) {
      appendMessage("ai", "你好，我可以解释概念、提醒你看材料、帮你梳理思路，但不会直接替你写实验答案。");
      return;
    }

    logs.slice(-20).forEach((log) => {
      appendMessage("user", log.question);
      appendMessage("ai", log.answer);
    });
  }

  function setOpen(open) {
    root.classList.toggle("is-open", open);
    dragControls.clamp();
    if (open) {
      renderHistory();
      syncAssessmentLock();
      setTimeout(() => {
        if (!assessmentLocked) input.focus();
      }, 80);
    } else if (voiceSession) {
      if (voiceSession.getState() === "recording") voiceSession.stop();
      if (voiceSession.getState() === "preparing") voiceSession.cancel();
    }
  }

  function buildLog(context, answer, failed = false) {
    return {
      timestamp: new Date().toISOString(),
      studentName: context.studentName,
      studentAge: context.studentAge,
      studentId: context.studentId,
      className: context.className,
      groupId: context.groupId,
      pageTitle: context.pageTitle,
      experimentName: context.experimentName,
      currentStep: context.currentStep,
      path: context.path,
      question: context.question,
      answer,
      experimentId: integration.resolveSourceModule("", context.path),
      failed
    };
  }

  function saveChatLog(context, answer, failed = false) {
    const logs = readLogs();
    logs.push(buildLog(context, answer, failed));
    saveLogs(logs);
  }

  function aiOutboxKey() {
    return platform.storage.scopedKey(platform.config.storageKeys.aiChatOutbox);
  }

  function readAiOutbox() {
    const value = readJson(aiOutboxKey(), { entries: [] });
    return value && Array.isArray(value.entries) ? value.entries : [];
  }

  function writeAiOutbox(entries) {
    localStorage.setItem(aiOutboxKey(), JSON.stringify({ schemaVersion: 1, updatedAt: new Date().toISOString(), entries: entries.slice(-200) }));
  }

  function buildAiChatRecord(context, answer) {
    const timestamp = new Date().toISOString();
    const experimentId = integration.resolveSourceModule("", context.path);
    return {
      schemaVersion: 1,
      clientRecordId: ["ai", context.studentId || "", experimentId || "unknown", timestamp].join("|"),
      studentId: context.studentId || "",
      experimentId,
      page: context.path || location.pathname,
      step: context.currentStep || "",
      question: context.question,
      answer,
      timestamp
    };
  }

  async function sendAiChatRecord(record) {
    const session = platform.identity.readStudentSession() || {};
    if (session.isGuest) return { ok: true, guest: true };
    if (!session.sessionToken) return { ok: false, code: "UNAUTHORIZED", retryable: true };
    try {
      const response = await fetch(platform.config.endpoints.saveAiChatRecord, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.sessionToken}` },
        body: JSON.stringify({ schemaVersion: 1, record })
      });
      const result = await response.json().catch(() => ({}));
      if (result.code === "UNAUTHORIZED") result.retryable = true;
      return Object.assign({ ok: response.ok && Boolean(result.ok) }, result);
    } catch (error) {
      return { ok: false, code: "NETWORK_ERROR", retryable: true };
    }
  }

  async function flushAiChatOutbox() {
    const entries = readAiOutbox();
    const remaining = [];
    for (const record of entries) {
      const result = await sendAiChatRecord(record);
      if (!result.ok && result.code !== "DUPLICATE" && result.retryable !== false) remaining.push(record);
    }
    writeAiOutbox(remaining);
    return { ok: remaining.length === 0, queued: remaining.length };
  }

  async function uploadAiChatRecord(context, answer) {
    const record = buildAiChatRecord(context, answer);
    const entries = readAiOutbox();
    if (!entries.some((item) => item.clientRecordId === record.clientRecordId)) entries.push(record);
    writeAiOutbox(entries);
    const result = await sendAiChatRecord(record);
    if (result.ok || result.code === "DUPLICATE" || result.retryable === false) {
      writeAiOutbox(readAiOutbox().filter((item) => item.clientRecordId !== record.clientRecordId));
    }
    return result;
  }

  function getCurrentPageLogs() {
    const identity = readIdentity();
    return readLogs().filter((log) => {
      if (identity.studentId && log.studentId && log.studentId !== identity.studentId) return false;
      return !log.path || log.path === location.pathname;
    }).map((log) => Object.assign({}, log, {
      studentName: log.studentName || identity.studentName || "",
      studentId: log.studentId || identity.studentId || "",
      className: log.className || identity.className || "",
      groupId: log.groupId || identity.groupId || "",
      path: log.path || location.pathname,
      experimentName: log.experimentName || getExperimentName(),
      currentStep: log.currentStep || getCurrentStep()
    }));
  }

  function makeAssistantError(reason) {
    return `AI 助手连接失败：${reason}`;
  }

  async function askAssistant(context) {
    const endpoint = getEndpoint();
    if (!endpoint) {
      throw new Error("AI 接口地址未配置，请在 assets/ai-assistant.js 中填写 AI_API_ENDPOINT。");
    }
    if (!/^(https?:\/\/|\/)/.test(endpoint)) {
      console.warn("[AI Assistant] endpoint should be an absolute URL or a root-relative path.");
    }

    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: context.question,
          pageTitle: context.pageTitle,
          experimentName: context.experimentName,
          currentStep: context.currentStep,
          path: context.path
        })
      });
    } catch (error) {
      console.error("[AI Assistant] fetch failed:", {
        name: (error && error.name) || "Error"
      });
      throw new Error("后端接口无法访问，请检查 AI 接口地址、网络或 CORS 配置。");
    }

    const data = await response.json().catch((error) => {
      console.error("[AI Assistant] response JSON parse failed:", {
        status: response.status,
        name: (error && error.name) || "Error"
      });
      return {};
    });

    if (!response.ok) {
      console.error("[AI Assistant] backend error:", {
        status: response.status,
        code: data.code || ""
      });
      const detail = data.error || `后端返回 HTTP ${response.status}`;
      throw new Error(detail);
    }

    const answer = data.reply || data.answer;
    if (!answer) {
      console.error("[AI Assistant] missing reply field:", {
        status: response.status
      });
      throw new Error("后端没有返回 reply 字段。");
    }
    return answer;
  }

  toggle.addEventListener("click", () => setOpen(true));
  close.addEventListener("click", () => setOpen(false));
  voiceButton.addEventListener("click", toggleVoiceInput);
  input.addEventListener("focus", () => syncAssessmentLock());

  document.addEventListener("virtual-agent:ai-opened", (event) => {
    syncAssessmentLock(event.detail?.stageId || "");
  });

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") voiceSession?.cancel();
  });
  window.addEventListener("pagehide", () => voiceSession?.destroy());
  window.addEventListener("beforeunload", () => voiceSession?.destroy());

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (syncAssessmentLock()) return;
    if (["preparing", "recording", "finalizing"].includes(voiceState)) return;
    const question = input.value.trim();
    if (!question) return;

    const context = getContext(question);
    appendMessage("user", question);
    input.value = "";
    requestPending = true;
    updateControls();
    const loading = appendMessage("ai", "我正在思考，先试着回到材料里找一个线索...");

    try {
      const answer = await askAssistant(context);
      loading.textContent = answer;
      saveChatLog(context, answer);
      uploadAiChatRecord(context, answer).catch(() => {});
    } catch (error) {
      const reason = error && error.message ? error.message : "网络请求失败。";
      const message = makeAssistantError(reason);
      loading.textContent = message;
      saveChatLog(context, `错误：${message}`, true);
    } finally {
      requestPending = false;
      syncAssessmentLock();
      if (!assessmentLocked) input.focus();
      messages.scrollTop = messages.scrollHeight;
    }
  });

  function initAssistant() {
    if (document.querySelector(".ai-assistant")) return;
    document.body.appendChild(root);
    renderHistory();
    updateControls();
    window.BrainAIChat = {
      readLogs,
      getCurrentPageLogs,
      buildAiChatRecord,
      uploadAiChatRecord,
      flushAiChatOutbox
    };
    flushAiChatOutbox().catch(() => {});
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initAssistant);
  } else {
    initAssistant();
  }
  window.addEventListener("online", () => flushAiChatOutbox().catch(() => {}));
})();
