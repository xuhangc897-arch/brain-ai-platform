"use strict";

const cloudbase = require("@cloudbase/node-sdk");

const STUDENTS_COLLECTION = "students";
const TEACHERS_COLLECTION = "teachers";
const CURRENT_SCHEMA_VERSION = 1;

const app = cloudbase.init({
  env: cloudbase.SYMBOL_CURRENT_ENV
});

const db = app.database();
const studentsCollection = db.collection(STUDENTS_COLLECTION);
const teachersCollection = db.collection(TEACHERS_COLLECTION);

async function isTeacher() {
  const context = typeof cloudbase.getCloudbaseContext === "function" ? cloudbase.getCloudbaseContext() : {};
  const uid = String(context.TCB_UUID || context.UID || context.OPENID || context.WX_OPENID || "").trim();
  if (!uid) return false;
  const result = await teachersCollection.where({ uid, active: true, role: "teacher" }).limit(1).get();
  return Array.isArray(result.data) && Boolean(result.data[0]);
}

function normalizeCell(value) {
  return String(value == null ? "" : value).trim();
}

function normalizeStudent(rawStudent) {
  const studentId = normalizeCell(rawStudent && rawStudent.studentId);
  const explicitPassword = normalizeCell(rawStudent && rawStudent.password);

  return {
    studentId,
    name: normalizeCell(rawStudent && rawStudent.name),
    class: normalizeCell(rawStudent && (rawStudent.class || rawStudent.className)),
    group: normalizeCell(rawStudent && (rawStudent.group || rawStudent.groupName)),
    password: explicitPassword || getDefaultPassword(studentId)
  };
}

function getDefaultPassword(studentId) {
  const normalizedStudentId = normalizeCell(studentId);
  return normalizedStudentId.length > 6
    ? normalizedStudentId.slice(-6)
    : normalizedStudentId;
}

function getErrorMessage(error) {
  return (error && (error.message || error.errMsg || error.msg)) || "未知错误";
}

function getErrorCode(error) {
  return (error && (error.code || error.errCode || error.errorCode || error.category)) || "";
}

async function findStudentByStudentId(studentId) {
  const result = await studentsCollection
    .where({ studentId })
    .limit(1)
    .get();

  if (result.code) {
    throw new Error("查询学生资料失败。");
  }

  const records = Array.isArray(result.data) ? result.data : [];
  return records[0] || null;
}

async function createStudentProfile(student) {
  const now = new Date();
  const result = await studentsCollection.add({
    schemaVersion: CURRENT_SCHEMA_VERSION,
    role: "student",
    studentId: student.studentId,
    name: student.name,
    class: student.class,
    group: student.group,
    password: student.password,
    mustChangePassword: true,
    createdAt: now,
    updatedAt: now
  });

  if (result.code) {
    throw new Error("写入学生资料失败。");
  }

  return result;
}

async function createOneStudent(rawStudent) {
  const student = normalizeStudent(rawStudent);

  if (!student.studentId || !student.name || !student.class || !student.group) {
    return {
      status: "failed",
      studentId: student.studentId,
      name: student.name,
      class: student.class,
      group: student.group,
      reason: "缺少学号、姓名、班级或小组。"
    };
  }

  try {
    const existingStudent = await findStudentByStudentId(student.studentId);

    if (existingStudent) {
      return {
        status: "skipped",
        studentId: student.studentId,
        name: student.name,
        class: student.class,
        group: student.group,
        reason: "studentId 已存在，已跳过，未覆盖密码。"
      };
    }

    await createStudentProfile(student);

    return {
      status: "success",
      studentId: student.studentId,
      name: student.name,
      class: student.class,
      group: student.group,
      reason: "学生资料已导入。"
    };
  } catch (error) {
    return {
      status: "failed",
      studentId: student.studentId,
      name: student.name,
      class: student.class,
      group: student.group,
      reason: getErrorMessage(error),
      code: getErrorCode(error)
    };
  }
}

function parsePayload(event) {
  if (event && typeof event.body === "string") {
    try {
      return JSON.parse(event.body);
    } catch (error) {
      return {};
    }
  }

  if (event && event.body && typeof event.body === "object") {
    return event.body;
  }

  return event || {};
}

exports.main = async (event) => {
  if (!await isTeacher()) {
    return { ok: false, code: "FORBIDDEN", message: "当前账号没有教师导入权限。", results: [] };
  }
  const payload = parsePayload(event);
  const students = Array.isArray(payload && payload.students) ? payload.students : [];

  if (students.length === 0) {
    return {
      ok: false,
      code: "EMPTY_STUDENTS",
      message: "没有收到可导入的学生数据。",
      results: []
    };
  }

  const results = [];

  for (const student of students) {
    results.push(await createOneStudent(student));
  }

  const success = results.filter((item) => item.status === "success").length;
  const skipped = results.filter((item) => item.status === "skipped").length;
  const failed = results.filter((item) => item.status === "failed").length;

  return {
    ok: true,
    success,
    skipped,
    failed,
    message: "学生资料已导入，可使用学号和默认密码登录。",
    results
  };
};
